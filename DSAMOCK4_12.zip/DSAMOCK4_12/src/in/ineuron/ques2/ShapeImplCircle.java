package in.ineuron.ques2;

public class ShapeImplCircle implements Shape {
	int radius=0;



	public ShapeImplCircle(int radius) {
		super();
		this.radius = radius;
	}

	public float area() {
		float area = (float) (Math.PI*radius*radius);
		return area;
		
	}
	
	public float perimeter() {
		float perimeter=(float) (Math.PI*2*radius);
		return perimeter;
		
	}

}
