package in.ineuron.ques2;

/*Create a superclass called Shape with an abstract method calculateArea()
that returns the area of the shape. Implement subclasses Rectangle, Circle, 
and Triangle that inherit from the Shape class. Implement the calculateArea() 
method in each subclass to calculate and return the area of a rectangle, circle,
and triangle, respectively. Then, create a class called ShapeCalculator
with a method printArea(Shape shape) that accepts an object of type Shape and prints its area.
Demonstrate polymorphism by passing instances of different subclasses to the printArea() method.*/

public interface Shape {
	
	public float area();
	
	public float perimeter();

}
