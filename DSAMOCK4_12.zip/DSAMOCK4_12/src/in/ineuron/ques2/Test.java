package in.ineuron.ques2;
import java.util.Scanner;
	public class Test {

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter radius of circle");
			int r = sc.nextInt();
			Shape shape1 =new ShapeImplCircle(r);
			 System.out.println("Area of circle is = "+ shape1.area());
	         System.out.println("Perimeter of circle is = "+ shape1.perimeter());
	         
			System.out.println("Enter three sides of triangle");
			float a = sc.nextFloat();
			float b = sc.nextFloat();
			float c = sc.nextFloat();
			System.out.println("Enter height of the triangle");
			float h = sc.nextFloat();
			Shape shape2=new ShapeImplTriangle(a, b, c, h);
		     System.out.println("Area of triangle is = "+ shape2.area());
		     System.out.println("Perimeter of triangle is = "+ shape2.perimeter());
			
			System.out.println("Enter side of the square");
			int side=sc.nextInt();
			
			
		
			Shape shape3=new ShapeImplSquare(side);
			
	        
	  
	         System.out.println("Area of square is = "+ shape3.area());
	         System.out.println("Perimeter of square is = "+ shape3.perimeter());
	         
	         sc.close();
		}

	}




