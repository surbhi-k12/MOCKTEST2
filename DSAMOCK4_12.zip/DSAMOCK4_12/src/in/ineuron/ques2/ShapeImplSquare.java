package in.ineuron.ques2;

public class ShapeImplSquare implements Shape {
	int side;
	float area=0;
	float perimeter=0;

	public ShapeImplSquare(int side) {
		super();
		this.side = side;
	}

	@Override
	public float area() {
		area=side*side;
		return area;
	}

	@Override
	public float perimeter() {
		// TODO Auto-generated method stub
		perimeter=4*side;
		return perimeter;
	}
}
