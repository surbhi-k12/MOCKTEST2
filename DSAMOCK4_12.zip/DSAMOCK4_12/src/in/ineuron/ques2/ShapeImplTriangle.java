package in.ineuron.ques2;

public class ShapeImplTriangle implements Shape{


	float a,b,c,h;
	
	public ShapeImplTriangle() {
		super();
	}

	public ShapeImplTriangle(float a, float b, float c, float h) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.h = h;
	}

	@Override
	public float area() {

     return (b*h)/2;
	}

	@Override
	public float perimeter() {
		
		return a+b+c;
	}

}
